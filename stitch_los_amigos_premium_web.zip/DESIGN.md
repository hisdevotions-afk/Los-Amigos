# Design System Strategy: The Cinematic Table

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Cinematic Table."** 

This isn’t just a menu; it’s a high-drama, editorial experience that mirrors the atmospheric, high-contrast lighting of a luxury dark-room lounge. We are moving away from the "grid-of-cards" template and toward a layout that feels like a premium lifestyle magazine. By utilizing intentional asymmetry, oversized serif typography that bleeds off-canvas, and "pools of light" created through gradients, we evoke the feeling of a candlelit dinner where the food is the protagonist.

We break the traditional digital "flatness" by treating the screen as a 3D space where ruby-red light catches the edges of surfaces, and charcoal depths hide secondary information until it’s needed.

---

## 2. Colors
Our palette is rooted in the "Noir" aesthetic, using deep blacks and charcoal to create a stage for our "Ruby Red" hero color.

### The Palette (Material Design Tokens)
*   **Base (Surface):** `#131313` (Deep Black)
*   **Accent (Primary):** `#ffb2be` (Ruby Glow) / `#9c003f` (Deep Ruby Container)
*   **Neutrals:** `#2a2a2a` (Surface Container High), `#c8c6c6` (Secondary/Silver Text)

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to define sections or cards. 
Boundaries must be created exclusively through background color shifts. For example, a card should sit as a `surface-container-high` (`#2a2a2a`) element on top of a `surface` (`#131313`) background. This creates a soft, sophisticated edge that feels architectural rather than "web-like."

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. 
1.  **Level 0 (The Void):** `surface_container_lowest` (#0e0e0e) for the deep background.
2.  **Level 1 (The Table):** `surface` (#131313) for the main content area.
3.  **Level 2 (The Plate):** `surface_container` (#201f1f) for interactive elements.
4.  **Level 3 (The Highlight):** `surface_bright` (#3a3939) for hovered or active states.

### The "Glass & Gradient" Rule
To mimic the atmospheric lighting in the reference imagery, use semi-transparent surfaces for floating navigation: 
*   **Backdrop:** `surface` at 70% opacity with a `24px` blur.
*   **CTAs:** Use a subtle radial gradient from `primary` (#ffb2be) to `primary_container` (#9c003f) to give buttons a "3D glow" rather than a flat fill.

---

## 3. Typography
The type system is a dialogue between tradition and modern utility.

*   **Display & Headlines (Noto Serif):** This is our "Editorial" voice. Use `display-lg` (3.5rem) for dish names and section headers. High-contrast serifs convey luxury and heritage. Don't be afraid to use tight letter-spacing (-0.02em) for a more bespoke feel.
*   **Body & Labels (Manrope):** Our "Utility" voice. Manrope provides a clean, geometric counter-balance to the serif. It ensures readability for descriptions and prices. Use `body-md` (0.875rem) for menu descriptions to keep the layout feeling light and airy.

**Hierarchy Strategy:** Always lead with a large Serif headline to set the mood, followed by a wide-tracked (0.05em) Manrope label for sub-text to create an "authoritative" feel.

---

## 4. Elevation & Depth
In "The Cinematic Table," we don't use shadows to show distance; we use light and tone.

*   **The Layering Principle:** Depth is achieved by stacking. A `surface-container-highest` menu item appears closer to the user because it is lighter than the `surface-container-low` background.
*   **Ambient Ruby Shadows:** When a true floating element (like a modal) is required, do not use black shadows. Use a highly diffused shadow (40px-60px blur) with a hint of our primary color: `rgba(156, 0, 63, 0.1)`. This mimics the "atmospheric lighting" where red light bounces off dark surfaces.
*   **The "Ghost Border" Fallback:** If accessibility requires a container edge, use the `outline_variant` (#5a403f) at **15% opacity**. This creates a "glint" on the edge of the container rather than a visible line.
*   **Glassmorphism:** Use for "floating" action buttons or top navigation to maintain the depth of the background photography, keeping the user immersed in the restaurant's vibe.

---

## 5. Components

### Buttons
*   **Primary:** Roundedness `md` (0.375rem). Background: Ruby Gradient. Typography: `label-md` in `on_primary` (#660026).
*   **Secondary:** Ghost style. No fill, `Ghost Border` (15% opacity), Typography in `primary` (#ffb2be).

### Cards & Menu Items
*   **Rule:** Forbid divider lines. 
*   **Layout:** Use `surface-container-low` with a `xl` (0.75rem) roundedness. Use `display-sm` for the price, positioned asymmetrically (e.g., top-right corner, overlapping the image).
*   **Interaction:** On hover, shift background to `surface-container-high` and add a subtle `primary` inner-glow.

### Input Fields
*   **Style:** Minimalist. No box. Only a bottom line using `outline_variant`.
*   **Active State:** The bottom line glows with a 2px `primary` shadow.

### Signature Component: The "Spotlight" Carousel
A full-screen horizontal scroll where the "active" item is crisp and saturated, while the "inactive" items are blurred (8px) and desaturated, drawing the user's eye exactly where we want it—much like a spotlight in a dark restaurant.

---

## 6. Do's and Don'ts

### Do:
*   **Do** use extreme whitespace (padding/margins). Luxury is defined by the space you *don't* use.
*   **Do** let food photography bleed behind text elements using the Glassmorphism rules.
*   **Do** use `on_surface_variant` (#e2bebc) for secondary text to maintain a warm, "ruby-tinted" dark mode.

### Don't:
*   **Don't** use 100% white (#FFFFFF). It is too harsh against the deep black. Always use `on_surface` (#e5e2e1).
*   **Don't** use standard "drop shadows." They look "cheap" in a luxury dark-mode context.
*   **Don't** use bright, saturated colors other than the Ruby Red. All other colors should be muted or tonal to ensure the brand identity remains focused.
*   **Don't** use sharp corners. Use the `md` to `xl` roundedness scale to keep the experience feeling "soft" and "inviting."

---
*Director's Note: Remember, we are not building a website; we are building a digital flagship. Every pixel must feel like it was placed by a sommelier.*